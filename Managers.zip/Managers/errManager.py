import sys
from Managers.prtManager import editPrintLogger
def catalogoErrores(error):
    editPrintLogger("ERROR NUM: "+ str(error[0]))
    if error[0] == 0:
        editPrintLogger("Error en duplicacion de variables: " + str(error[0]))
        sys.exit()
    elif error[0] == 1:
        editPrintLogger("Error en duplicacion de funciones: " + str(error[0]))
        sys.exit()
    elif error[0] == 2:
        editPrintLogger("Error: Type mismatch: " + str(error[1]) + "-" + str(error[2]))
        sys.exit()
    elif error[0] == 3:
        editPrintLogger("Errors: Fake floor inexistente")
        sys.exit()
    elif error[0] == 4:
        editPrintLogger("Error: Type mistmatch en parametros"+ str(error[1]) + " " + str(error[2]))
        sys.exit()
    elif error[0] == 5:
        editPrintLogger("Error: Numero de parametros no valido")
        sys.exit()
    elif error[0] == 6:
        editPrintLogger("Error: Return en funcion VOID. " + str(error[1]))
        sys.exit()
    elif error[0] == 7:
        editPrintLogger("Error: Variable no declarada " + str(error[1]))
        sys.exit()
    elif error[0] == 8:
        editPrintLogger("Error tipo invalido en for loop")
        sys.exit()
    elif error[0] == 9:
        editPrintLogger("Error en la lectura del archivo")
        sys.exit()
    elif error[0] == 10:
        editPrintLogger("Error: Llamando dimensiones dentro de una variable no arreglo " + str(error[1]))
        sys.exit()
    elif error[0] == 11:
        editPrintLogger("Error: Final de codigo inesperado")
        sys.exit()
    elif error[0] == 12:
        editPrintLogger("Error: Valor fuera del rango del arreglo " + str(error[1]))
        sys.exit()
    elif error[0] == 13:
        editPrintLogger("Error: Asignacion de tipo incorrecta " + str(error[1]) + " " + str(error[2]))
        sys.exit()
    else:
        editPrintLogger(error[0])
        sys.exit(error[0])
